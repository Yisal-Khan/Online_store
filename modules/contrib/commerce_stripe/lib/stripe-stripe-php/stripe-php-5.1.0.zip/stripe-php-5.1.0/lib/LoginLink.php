<?php

namespace Stripe;

/**
 * Class LoginLink
 *
 * @package Stripe
 */
class LoginLink extends ApiResource
{

}
